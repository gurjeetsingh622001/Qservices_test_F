import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-u-dash',
  templateUrl: './u-dash.component.html',
  styleUrls: ['./u-dash.component.css']
})
export class UDashComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
